#include "telegard.h"

void main()
{
printf("\nRecord Sizes (Telegard structures only!)\n\n");
printf("ConfigRec =   %i\n",sizeof(configrec));
printf("SystemRec =   %i\n",sizeof(systemrec));
printf("UserRec =     %i\n",sizeof(userrec));
printf("  .UserFlags  = %i\n",sizeof(userflags));
printf("  .UserStatus = %i\n",sizeof(userstatus));
printf("  .uflags     = %i\n",sizeof(uflags));
printf("  .acrqs      = %i\n",sizeof(acrqs));
printf("UserIdxRec =  %i\n",sizeof(useridxrec));
printf("IDIdxRec =    %i\n",sizeof(IDidxrec));
printf("AreaIdxRec =  %i\n",sizeof(areaidxrec));
printf("FAreaRec =    %i\n",sizeof(farearec));
printf("FileIdxRec =  %i\n",sizeof(fileidxrec));
printf("FbRec =       %i\n",sizeof(fbrec));
printf("DriveRec =    %i\n",sizeof(driverec));
printf("QueueRec =    %i\n",sizeof(queuerec));
printf("MAreaRec =    %i\n",sizeof(marearec));
printf("MenuHdrRec =  %i\n",sizeof(menurec));
printf("MenuItemRec = %i\n",sizeof(commandrec));
printf("BbsListRec =  %i\n",sizeof(bbslistrec));
printf("ArchiveRec =  %i\n",sizeof(archiverec));
printf("GroupRec =    %i\n",sizeof(groupsrec));
printf("EventRec =    %i\n",sizeof(eventrec));
printf("HistoryRec =  %i\n",sizeof(historyrec));
printf("IemsiRec =    %i\n",sizeof(iemsirec));
printf("LanguageRec = %i\n",sizeof(languagerec));
printf("LCallersRec = %i\n",sizeof(lcallers));
printf("LevelsRec =   %i\n",sizeof(levelsrec));
printf("MacroRec =    %i\n",sizeof(macrorec));
printf("ModemRec =    %i\n",sizeof(modemrec));
printf("NetworkRec =  %i\n",sizeof(networkrec));
printf("NodesRec =    %i\n",sizeof(nodesrec));
printf("ProtRec =     %i\n",sizeof(protrec));
printf("ShortMsgRec = %i\n",sizeof(shortmsgrec));
printf("SigsRec =     %i\n",sizeof(sigsrec));
printf("SmacroRec =   %i\n",sizeof(smacrorec));
printf("TimelogRec =  %i\n",sizeof(timelogrec));
printf("VoteRec =     %i\n",sizeof(voterec));
}
